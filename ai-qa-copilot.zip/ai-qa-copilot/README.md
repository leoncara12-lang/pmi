# AI QA & Compliance Copilot (MVP) — Full-Stack App
Questo repository è un MVP **end-to-end** (landing page + login + dashboard + backend + DB) per:
- Importare conversazioni (chat/email) via JSON/CSV
- Eseguire **PII redaction**, **Compliance checks** (regole) e **QA scoring**
- Mostrare dashboard e dettagli conversazione
- Gestire regole/policy e Knowledge Base (per il passo Agent Assist)

> Nota: il modulo “Agent Assist” qui è incluso come **KB + Retrieval stub**. Per usare un LLM reale, imposta `LLM_PROVIDER=openai` e `OPENAI_API_KEY=...` (vedi `.env.example`). Se non imposti un LLM, l’app usa un **fallback deterministico/euristico** (utile per pilot).

---

## Requisiti
- Docker + Docker Compose
- (Opzionale) Node 18+ se vuoi eseguire frontend fuori da Docker

---

## Quick start (tutto con Docker)
1. Copia le variabili:
```bash
cp .env.example .env
```

2. Avvia:
```bash
docker compose up --build
```

3. Apri:
- Frontend: http://localhost:3000
- Backend docs (Swagger): http://localhost:8000/docs

---

## Credenziali
Non ci sono credenziali predefinite.
- Registrati da UI oppure via API: `POST /auth/register`

Ruoli supportati:
- `admin`
- `qa_lead`
- `supervisor`
- `agent`

---

## Import conversazioni (MVP)
### JSON
`POST /conversations/import/json`
- Body: un array di conversazioni o una singola conversazione.

Formato (esempio minimo):
```json
{
  "channel": "chat",
  "queue": "billing",
  "external_id": "ZENDESK-123",
  "started_at": "2025-12-30T10:00:00Z",
  "ended_at": "2025-12-30T10:12:00Z",
  "messages": [
    {"speaker":"customer","ts":"2025-12-30T10:00:01Z","text":"Ciao, il mio CF è RSSMRA..."},
    {"speaker":"agent","ts":"2025-12-30T10:00:10Z","text":"Certo, verifico subito."}
  ]
}
```

### CSV
`POST /conversations/import/csv`
CSV con colonne minime:
- conversation_external_id, channel, queue, speaker, ts, text

---

## Sicurezza (MVP)
- JWT auth (access token)
- Password hashing (bcrypt)
- RBAC base su endpoint admin
- Audit log minimale (login, import, run QA)

> Produzione: aggiungi refresh token, httpOnly cookies, rate limiting, e isolamenti tenant più rigidi.

---

## Struttura
- `backend/` FastAPI + SQLModel + Celery (opzionale)
- `frontend/` Next.js (landing + auth + dashboard)

---

## Esempi rapidi API
Login:
```bash
curl -X POST http://localhost:8000/auth/login -H "Content-Type: application/json"   -d '{"email":"a@b.com","password":"Password123!"}'
```

Esegui QA su una conversazione:
```bash
curl -X POST http://localhost:8000/conversations/{id}/run_qa -H "Authorization: Bearer <TOKEN>"
```

---

## License
MIT
