from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .settings import settings
from .db import init_db
from .routers import auth, conversations, policies, kb, dashboard

app = FastAPI(title="AI QA & Compliance Copilot API", version="0.1.0")

origins = [o.strip() for o in settings.CORS_ORIGINS.split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins if origins else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    init_db()

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(conversations.router, prefix="/conversations", tags=["conversations"])
app.include_router(policies.router, prefix="/policies", tags=["policies"])
app.include_router(kb.router, prefix="/kb", tags=["kb"])
app.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
