from __future__ import annotations
from typing import Optional, List, Dict, Any
from datetime import datetime
from sqlmodel import SQLModel, Field, Relationship, Column, JSON

class Tenant(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)

    users: List["User"] = Relationship(back_populates="tenant")

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    tenant_id: int = Field(foreign_key="tenant.id", index=True)
    email: str = Field(index=True, unique=True)
    full_name: str = ""
    role: str = Field(default="agent", index=True)  # admin|qa_lead|supervisor|agent
    hashed_password: str
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)

    tenant: Optional[Tenant] = Relationship(back_populates="users")

class Conversation(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    tenant_id: int = Field(index=True)
    channel: str = Field(index=True)  # chat|email|voice
    queue: str = Field(default="general", index=True)
    external_id: str = Field(default="", index=True)

    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    agent_email: str = ""
    customer_id_hash: str = ""

    metadata: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))

    messages: List["Message"] = Relationship(back_populates="conversation")
    qa_result: Optional["QAResult"] = Relationship(back_populates="conversation")

class Message(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    conversation_id: int = Field(foreign_key="conversation.id", index=True)
    speaker: str = Field(index=True)  # customer|agent|system
    ts: Optional[datetime] = None
    text: str
    text_redacted: str = ""

    conversation: Optional[Conversation] = Relationship(back_populates="messages")

class QAResult(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    conversation_id: int = Field(foreign_key="conversation.id", index=True, unique=True)
    rubric_version: str = Field(default="v1")
    score_json: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    issues_json: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    summary: str = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)

    conversation: Optional[Conversation] = Relationship(back_populates="qa_result")

class PolicyRule(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    tenant_id: int = Field(index=True)
    name: str = Field(index=True)
    rule_type: str = Field(index=True)  # regex|must_include|forbidden|llm_context
    pattern: str = ""
    severity: str = Field(default="medium")  # low|medium|high
    locale: str = Field(default="it-IT")
    active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)

class KBDoc(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    tenant_id: int = Field(index=True)
    source: str = Field(default="manual")
    title: str
    body: str
    tags: str = ""
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class AuditLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    tenant_id: int = Field(index=True)
    user_id: Optional[int] = Field(default=None, index=True)
    action: str = Field(index=True)
    details: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)
