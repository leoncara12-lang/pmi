from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlmodel import Session, select

from ..db import get_session
from ..models import User, Tenant, AuditLog
from ..security import hash_password, verify_password, create_access_token
from ..deps import get_current_user

router = APIRouter()

class RegisterIn(BaseModel):
    tenant_name: str = "default"
    email: EmailStr
    password: str
    full_name: str = ""
    role: str = "admin"  # first user as admin by default

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class MeOut(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    role: str
    tenant_id: int

@router.post("/register", response_model=MeOut)
def register(data: RegisterIn, session: Session = Depends(get_session)):
    tenant = session.exec(select(Tenant).where(Tenant.name == data.tenant_name)).first()
    if not tenant:
        tenant = Tenant(name=data.tenant_name)
        session.add(tenant)
        session.commit()
        session.refresh(tenant)

    existing = session.exec(select(User).where(User.email == data.email)).first()
    if existing:
        raise HTTPException(400, "Email already registered")

    user = User(
        tenant_id=tenant.id,
        email=data.email,
        full_name=data.full_name,
        role=data.role,
        hashed_password=hash_password(data.password),
    )
    session.add(user)
    session.commit()
    session.refresh(user)

    session.add(AuditLog(tenant_id=tenant.id, user_id=user.id, action="register", details={"email": data.email}))
    session.commit()

    return MeOut(id=user.id, email=user.email, full_name=user.full_name, role=user.role, tenant_id=user.tenant_id)

@router.post("/login", response_model=TokenOut)
def login(data: LoginIn, session: Session = Depends(get_session)):
    user = session.exec(select(User).where(User.email == data.email)).first()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(401, "Invalid credentials")
    token = create_access_token(sub=user.email, tenant_id=user.tenant_id, role=user.role, user_id=user.id)
    session.add(AuditLog(tenant_id=user.tenant_id, user_id=user.id, action="login", details={"email": user.email}))
    session.commit()
    return TokenOut(access_token=token)

@router.get("/me", response_model=MeOut)
def me(user: User = Depends(get_current_user)):
    return MeOut(id=user.id, email=user.email, full_name=user.full_name, role=user.role, tenant_id=user.tenant_id)
