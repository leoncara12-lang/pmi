from __future__ import annotations
from typing import List, Optional, Dict, Any
from datetime import datetime
import csv
import io

from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select

from ..db import get_session
from ..models import Conversation, Message, QAResult, AuditLog
from ..deps import get_current_user, require_roles
from ..models import User
from ..services.redaction import redact
from ..services.compliance import run_compliance
from ..services.qa import heuristic_score, llm_score

router = APIRouter()

class MessageIn(BaseModel):
    speaker: str
    ts: Optional[datetime] = None
    text: str

class ConversationIn(BaseModel):
    channel: str = "chat"
    queue: str = "general"
    external_id: str = ""
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    agent_email: str = ""
    customer_id_hash: str = ""
    metadata: Dict[str, Any] = {}
    messages: List[MessageIn]

class ConversationOut(BaseModel):
    id: int
    channel: str
    queue: str
    external_id: str
    started_at: Optional[datetime]
    ended_at: Optional[datetime]

@router.get("/", response_model=List[ConversationOut])
def list_conversations(
    q: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
):
    stmt = select(Conversation).where(Conversation.tenant_id == user.tenant_id).order_by(Conversation.id.desc())
    if q:
        stmt = stmt.where(Conversation.external_id.contains(q) | Conversation.queue.contains(q))
    rows = session.exec(stmt.offset(offset).limit(limit)).all()
    return [ConversationOut(id=r.id, channel=r.channel, queue=r.queue, external_id=r.external_id,
                            started_at=r.started_at, ended_at=r.ended_at) for r in rows]

@router.get("/{conversation_id}")
def get_conversation(
    conversation_id: int,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
):
    conv = session.get(Conversation, conversation_id)
    if not conv or conv.tenant_id != user.tenant_id:
        raise HTTPException(404, "Not found")
    msgs = session.exec(select(Message).where(Message.conversation_id == conv.id).order_by(Message.id)).all()
    qa = session.exec(select(QAResult).where(QAResult.conversation_id == conv.id)).first()
    return {
        "conversation": conv.model_dump(),
        "messages": [m.model_dump() for m in msgs],
        "qa_result": qa.model_dump() if qa else None,
    }

@router.post("/import/json")
def import_json(
    payload: Any,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
):
    # payload can be a dict (single) or list
    items = payload if isinstance(payload, list) else [payload]
    created = 0
    for item in items:
        data = ConversationIn.model_validate(item)
        conv = Conversation(
            tenant_id=user.tenant_id,
            channel=data.channel,
            queue=data.queue,
            external_id=data.external_id,
            started_at=data.started_at,
            ended_at=data.ended_at,
            agent_email=data.agent_email,
            customer_id_hash=data.customer_id_hash,
            metadata=data.metadata,
        )
        session.add(conv)
        session.commit()
        session.refresh(conv)

        for mi in data.messages:
            red, _ = redact(mi.text)
            msg = Message(conversation_id=conv.id, speaker=mi.speaker, ts=mi.ts, text=mi.text, text_redacted=red)
            session.add(msg)
        session.commit()
        created += 1

    session.add(AuditLog(tenant_id=user.tenant_id, user_id=user.id, action="import_json", details={"count": created}))
    session.commit()
    return {"ok": True, "created": created}

@router.post("/import/csv")
def import_csv(
    file: UploadFile = File(...),
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
):
    raw = file.file.read().decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(raw))
    # group rows by conversation_external_id
    grouped: Dict[str, List[Dict[str, str]]] = {}
    for row in reader:
        cid = row.get("conversation_external_id") or row.get("external_id") or ""
        if not cid:
            continue
        grouped.setdefault(cid, []).append(row)

    created = 0
    for external_id, rows in grouped.items():
        channel = rows[0].get("channel", "chat")
        queue = rows[0].get("queue", "general")
        conv = Conversation(tenant_id=user.tenant_id, channel=channel, queue=queue, external_id=external_id)
        session.add(conv)
        session.commit()
        session.refresh(conv)
        for r in rows:
            text = r.get("text", "")
            red, _ = redact(text)
            ts = r.get("ts")
            dt = None
            if ts:
                try:
                    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                except Exception:
                    dt = None
            msg = Message(conversation_id=conv.id, speaker=r.get("speaker", "customer"), ts=dt, text=text, text_redacted=red)
            session.add(msg)
        session.commit()
        created += 1

    session.add(AuditLog(tenant_id=user.tenant_id, user_id=user.id, action="import_csv", details={"count": created}))
    session.commit()
    return {"ok": True, "created": created, "conversations": list(grouped.keys())[:20]}

@router.post("/{conversation_id}/run_qa")
async def run_qa(
    conversation_id: int,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
):
    conv = session.get(Conversation, conversation_id)
    if not conv or conv.tenant_id != user.tenant_id:
        raise HTTPException(404, "Not found")
    msgs = session.exec(select(Message).where(Message.conversation_id == conv.id).order_by(Message.id)).all()
    texts = [m.text_redacted or m.text for m in msgs]

    compliance = run_compliance(session=session, tenant_id=user.tenant_id, texts=texts)

    llm = await llm_score(texts)
    qa = llm or heuristic_score(texts)

    # issues derived
    issues = {"compliance": compliance, "notes": qa.get("notes", "")}

    existing = session.exec(select(QAResult).where(QAResult.conversation_id == conv.id)).first()
    if existing:
        existing.rubric_version = qa.get("rubric_version", "v1")
        existing.score_json = qa
        existing.issues_json = issues
        existing.summary = build_summary(qa, compliance)
        session.add(existing)
    else:
        r = QAResult(
            conversation_id=conv.id,
            rubric_version=qa.get("rubric_version", "v1"),
            score_json=qa,
            issues_json=issues,
            summary=build_summary(qa, compliance),
        )
        session.add(r)
    session.add(AuditLog(tenant_id=user.tenant_id, user_id=user.id, action="run_qa", details={"conversation_id": conv.id}))
    session.commit()
    return {"ok": True, "conversation_id": conv.id}

def build_summary(qa: Dict[str, Any], compliance: Dict[str, Any]) -> str:
    overall = qa.get("overall", 0)
    hi = compliance.get("summary", {}).get("high", 0)
    md = compliance.get("summary", {}).get("medium", 0)
    return f"QA overall={overall}/100; compliance findings high={hi}, medium={md}."
