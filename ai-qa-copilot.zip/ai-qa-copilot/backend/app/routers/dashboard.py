from fastapi import APIRouter, Depends
from sqlmodel import Session, select, func

from ..db import get_session
from ..models import Conversation, QAResult, User
from ..deps import get_current_user

router = APIRouter()

@router.get("/overview")
def overview(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    total_conversations = session.exec(
        select(func.count()).select_from(Conversation).where(Conversation.tenant_id == user.tenant_id)
    ).one()

    total_qa = session.exec(
        select(func.count()).select_from(QAResult)
    ).one()

    latest = session.exec(
        select(Conversation).where(Conversation.tenant_id == user.tenant_id).order_by(Conversation.id.desc()).limit(5)
    ).all()

    return {
        "total_conversations": int(total_conversations),
        "total_qa_results": int(total_qa),
        "latest": [{"id": c.id, "queue": c.queue, "channel": c.channel, "external_id": c.external_id} for c in latest],
    }
