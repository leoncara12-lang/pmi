from typing import List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select

from ..db import get_session
from ..models import KBDoc, AuditLog, User
from ..deps import get_current_user, require_roles
from ..services.agent_assist import simple_retrieve

router = APIRouter()

class KBDocIn(BaseModel):
    title: str
    body: str
    tags: str = ""
    source: str = "manual"

@router.get("/", response_model=List[KBDoc])
def list_docs(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    return session.exec(select(KBDoc).where(KBDoc.tenant_id == user.tenant_id).order_by(KBDoc.id.desc())).all()

@router.post("/", response_model=KBDoc)
def create_doc(
    data: KBDocIn,
    user: User = Depends(require_roles("admin", "qa_lead")),
    session: Session = Depends(get_session),
):
    doc = KBDoc(tenant_id=user.tenant_id, **data.model_dump())
    session.add(doc)
    session.add(AuditLog(tenant_id=user.tenant_id, user_id=user.id, action="create_kb_doc", details={"title": data.title}))
    session.commit()
    session.refresh(doc)
    return doc

@router.get("/retrieve")
def retrieve(query: str, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    return {"results": simple_retrieve(session, user.tenant_id, query=query, k=5)}
