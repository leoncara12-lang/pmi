from typing import List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select

from ..db import get_session
from ..models import PolicyRule, AuditLog, User
from ..deps import get_current_user, require_roles

router = APIRouter()

class RuleIn(BaseModel):
    name: str
    rule_type: str  # regex|must_include|forbidden|llm_context
    pattern: str = ""
    severity: str = "medium"
    locale: str = "it-IT"
    active: bool = True

@router.get("/", response_model=List[PolicyRule])
def list_rules(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    return session.exec(select(PolicyRule).where(PolicyRule.tenant_id == user.tenant_id).order_by(PolicyRule.id.desc())).all()

@router.post("/", response_model=PolicyRule)
def create_rule(
    data: RuleIn,
    user: User = Depends(require_roles("admin", "qa_lead")),
    session: Session = Depends(get_session),
):
    rule = PolicyRule(tenant_id=user.tenant_id, **data.model_dump())
    session.add(rule)
    session.add(AuditLog(tenant_id=user.tenant_id, user_id=user.id, action="create_rule", details={"name": data.name}))
    session.commit()
    session.refresh(rule)
    return rule

@router.delete("/{rule_id}")
def delete_rule(
    rule_id: int,
    user: User = Depends(require_roles("admin", "qa_lead")),
    session: Session = Depends(get_session),
):
    rule = session.get(PolicyRule, rule_id)
    if not rule or rule.tenant_id != user.tenant_id:
        raise HTTPException(404, "Not found")
    session.delete(rule)
    session.add(AuditLog(tenant_id=user.tenant_id, user_id=user.id, action="delete_rule", details={"rule_id": rule_id}))
    session.commit()
    return {"ok": True}
