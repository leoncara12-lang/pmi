from sqlmodel import Session, select
from .db import engine
from .models import Tenant, PolicyRule

DEFAULT_RULES = [
    {"name": "Disclosure obbligatoria (registrazione)", "rule_type": "must_include", "pattern": r"(registrat|registrazione|monitorat)", "severity": "medium"},
    {"name": "Divieto: promettere rimborsi non autorizzati", "rule_type": "forbidden", "pattern": r"(rimborso\s+garantito|ti\s+rimborsiamo\s+sempre)", "severity": "high"},
    {"name": "Richiesta PII (pattern IBAN)", "rule_type": "regex", "pattern": r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b", "severity": "medium"},
]

def run():
    with Session(engine) as session:
        tenant = session.exec(select(Tenant).where(Tenant.name=="default")).first()
        if not tenant:
            tenant = Tenant(name="default")
            session.add(tenant)
            session.commit()
            session.refresh(tenant)
        for r in DEFAULT_RULES:
            pr = PolicyRule(tenant_id=tenant.id, **r)
            session.add(pr)
        session.commit()
        print("Seeded rules for tenant 'default'")

if __name__ == "__main__":
    run()
