from typing import List, Dict, Any
from sqlmodel import Session, select
from ..models import KBDoc

def simple_retrieve(session: Session, tenant_id: int, query: str, k: int = 5) -> List[Dict[str, Any]]:
    # MVP: retrieval naive (full-text LIKE). In prod: embeddings + pgvector + hybrid.
    q = f"%{query.lower()}%"
    docs = session.exec(
        select(KBDoc).where(KBDoc.tenant_id == tenant_id)
    ).all()
    scored = []
    for d in docs:
        hay = (d.title + "\n" + d.body).lower()
        score = hay.count(query.lower())
        if score > 0 or query.lower() in hay:
            scored.append((score, d))
    scored.sort(key=lambda x: x[0], reverse=True)
    out = []
    for score, d in scored[:k]:
        out.append({"id": d.id, "title": d.title, "snippet": d.body[:400], "score": score})
    return out
