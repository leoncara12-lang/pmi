import re
from typing import List, Dict, Any
from sqlmodel import Session, select
from ..models import PolicyRule

def run_compliance(session: Session, tenant_id: int, texts: List[str]) -> Dict[str, Any]:
    rules = session.exec(
        select(PolicyRule).where(PolicyRule.tenant_id == tenant_id, PolicyRule.active == True)  # noqa: E712
    ).all()

    joined = "\n".join(texts)
    findings: List[Dict[str, Any]] = []

    for r in rules:
        if r.rule_type == "forbidden":
            if r.pattern and re.search(r.pattern, joined, flags=re.I|re.M):
                findings.append({"rule_id": r.id, "name": r.name, "severity": r.severity, "type": r.rule_type,
                                 "message": f"Contenuto vietato trovato: {r.pattern}"})
        elif r.rule_type == "must_include":
            if r.pattern and not re.search(r.pattern, joined, flags=re.I|re.M):
                findings.append({"rule_id": r.id, "name": r.name, "severity": r.severity, "type": r.rule_type,
                                 "message": f"Elemento obbligatorio mancante: {r.pattern}"})
        elif r.rule_type == "regex":
            if r.pattern:
                m = re.findall(r.pattern, joined, flags=re.I|re.M)
                if m:
                    findings.append({"rule_id": r.id, "name": r.name, "severity": r.severity, "type": r.rule_type,
                                     "message": f"Match regex: {r.pattern}", "matches_count": len(m)})
        # llm_context non usata nel MVP (serve per prompt/guardrail avanzati)

    summary = {
        "total_findings": len(findings),
        "high": sum(1 for f in findings if f.get("severity") == "high"),
        "medium": sum(1 for f in findings if f.get("severity") == "medium"),
        "low": sum(1 for f in findings if f.get("severity") == "low"),
    }
    return {"summary": summary, "findings": findings}
