from __future__ import annotations
from typing import List, Dict, Any, Optional
from datetime import datetime
import httpx

from ..settings import settings

RUBRIC_V1 = {
    "dimensions": [
        {"key": "accuracy", "label": "Accuratezza", "weight": 0.35},
        {"key": "tone", "label": "Tono/Empatia", "weight": 0.20},
        {"key": "process", "label": "Aderenza procedura", "weight": 0.25},
        {"key": "resolution", "label": "Chiarezza/Risoluzione", "weight": 0.20},
    ]
}

def heuristic_score(texts: List[str]) -> Dict[str, Any]:
    joined = "\n".join(texts).lower()
    # euristiche semplici (MVP): presenza di scuse, ringraziamenti, chiarezza
    tone = 70
    if "grazie" in joined or "gentile" in joined or "capisco" in joined:
        tone += 10
    if "non so" in joined or "non posso" in joined:
        tone -= 10

    accuracy = 75
    if "verifico" in joined or "controllo" in joined:
        accuracy += 5
    if "forse" in joined or "probabilmente" in joined:
        accuracy -= 10

    process = 70
    if "numero pratica" in joined or "ticket" in joined:
        process += 5

    resolution = 72
    if "risolto" in joined or "conferm" in joined:
        resolution += 8

    dims = {"accuracy": clamp(accuracy), "tone": clamp(tone), "process": clamp(process), "resolution": clamp(resolution)}
    overall = weighted_overall(dims, RUBRIC_V1["dimensions"])
    return {"rubric_version": "v1", "dimensions": dims, "overall": overall, "generated_by": "heuristic"}

def clamp(v: int) -> int:
    return max(0, min(100, v))

def weighted_overall(dims: Dict[str, int], spec) -> int:
    total = 0.0
    wsum = 0.0
    for d in spec:
        w = float(d["weight"])
        total += w * float(dims.get(d["key"], 0))
        wsum += w
    return int(round(total / wsum)) if wsum else 0

async def llm_score(texts: List[str]) -> Optional[Dict[str, Any]]:
    if settings.LLM_PROVIDER.lower() != "openai" or not settings.OPENAI_API_KEY:
        return None

    # Minimal OpenAI-compatible call (works with OpenAI API style / or compatible gateways)
    prompt = """Sei un QA lead per un contact center. Valuta la conversazione secondo queste dimensioni:
- accuracy (0-100)
- tone (0-100)
- process (0-100)
- resolution (0-100)
Rispondi SOLO in JSON con le chiavi: accuracy,tone,process,resolution,notes (string breve).
Conversazione:
""" + "\n".join(texts[-80:])

    headers = {"Authorization": f"Bearer {settings.OPENAI_API_KEY}"}
    payload = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": "Sei un valutatore QA. Rispondi solo JSON valido."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.2,
        "response_format": {"type": "json_object"},
    }
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            content = data["choices"][0]["message"]["content"]
            # content dovrebbe essere JSON
            import json
            parsed = json.loads(content)
            dims = {
                "accuracy": clamp(int(parsed.get("accuracy", 0))),
                "tone": clamp(int(parsed.get("tone", 0))),
                "process": clamp(int(parsed.get("process", 0))),
                "resolution": clamp(int(parsed.get("resolution", 0))),
            }
            overall = weighted_overall(dims, RUBRIC_V1["dimensions"])
            return {
                "rubric_version": "v1",
                "dimensions": dims,
                "overall": overall,
                "notes": str(parsed.get("notes", ""))[:500],
                "generated_by": "llm_openai",
            }
    except Exception:
        return None
