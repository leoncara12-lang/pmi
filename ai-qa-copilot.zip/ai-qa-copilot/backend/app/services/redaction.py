import re
from typing import Tuple, Dict

PII_PATTERNS = {
    "email": re.compile(r"([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})", re.I),
    "iban": re.compile(r"\b([A-Z]{2}\d{2}[A-Z0-9]{11,30})\b"),
    "phone": re.compile(r"(\+?\d{1,3}[\s-]?)?(\(?\d{2,4}\)?[\s-]?)?\d{6,10}"),
    "fiscal_code_it": re.compile(r"\b([A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z])\b", re.I),
    "cc_number": re.compile(r"\b(?:\d[ -]*?){13,19}\b"),
}

def redact(text: str) -> Tuple[str, Dict[str, int]]:
    counts = {}
    red = text
    for name, pat in PII_PATTERNS.items():
        red, n = pat.subn(f"[REDACTED_{name.upper()}]", red)
        if n:
            counts[name] = n
    return red, counts
