from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str
    JWT_SECRET: str
    JWT_EXPIRES_MINUTES: int = 240
    CORS_ORIGINS: str = "http://localhost:3000"

    # LLM (optional)
    LLM_PROVIDER: str = "none"  # none|openai
    OPENAI_API_KEY: str = ""

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
