from celery import Celery
from .settings import settings

celery_app = Celery(
    "aiqa",
    broker="redis://redis:6379/0",
    backend="redis://redis:6379/0",
)
celery_app.conf.update(task_track_started=True, task_time_limit=120)

@celery_app.task(name="aiqa.ping")
def ping():
    return {"ok": True}
