"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { apiFetch } from "../../lib/api";

export default function Conversations() {
  const [rows, setRows] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [err, setErr] = useState<string | null>(null);

  const load = async () => {
    try {
      const data = await apiFetch(`/conversations?q=${encodeURIComponent(q)}`);
      setRows(data);
    } catch {
      setErr("Errore nel caricamento (login?).");
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-zinc-200 bg-white p-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="text-xl font-semibold">Conversations</div>
            <div className="text-sm text-zinc-600 mt-1">Lista conversazioni importate.</div>
          </div>
          <div className="flex gap-2">
            <input className="rounded-xl border border-zinc-200 px-3 py-2 text-sm"
              value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Cerca (queue/external_id)" />
            <button className="rounded-xl bg-zinc-900 text-white px-4 py-2 text-sm" onClick={load}>Cerca</button>
          </div>
        </div>
        {err && <div className="mt-3 text-sm text-red-700">{err}</div>}
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white overflow-hidden">
        <div className="grid grid-cols-12 gap-2 px-4 py-3 text-xs text-zinc-500 border-b border-zinc-200">
          <div className="col-span-2">ID</div>
          <div className="col-span-4">External</div>
          <div className="col-span-2">Queue</div>
          <div className="col-span-2">Channel</div>
          <div className="col-span-2">Started</div>
        </div>
        {rows.map((r:any) => (
          <Link key={r.id} href={`/app/conversations/${r.id}`} className="grid grid-cols-12 gap-2 px-4 py-3 text-sm hover:bg-zinc-50">
            <div className="col-span-2 text-zinc-600">{r.id}</div>
            <div className="col-span-4 font-medium">{r.external_id || "-"}</div>
            <div className="col-span-2">{r.queue}</div>
            <div className="col-span-2">{r.channel}</div>
            <div className="col-span-2 text-zinc-600">{r.started_at ? String(r.started_at).slice(0,10) : "-"}</div>
          </Link>
        ))}
        {rows.length === 0 && <div className="p-6 text-sm text-zinc-600">Nessuna conversazione. Importa via API.</div>}
      </div>
    </div>
  );
}
