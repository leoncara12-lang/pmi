"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "../../lib/api";

export default function KBPage() {
  const [docs, setDocs] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [form, setForm] = useState({ title: "", body: "", tags: "" });
  const [err, setErr] = useState<string | null>(null);

  const load = () => apiFetch("/kb").then(setDocs).catch(()=>setErr("Errore caricamento"));

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-zinc-200 bg-white p-6">
        <div className="text-xl font-semibold">Knowledge Base</div>
        <div className="text-sm text-zinc-600 mt-1">Aggiungi procedure/FAQ. Retrieval MVP con LIKE (no embeddings).</div>
        {err && <div className="mt-3 text-sm text-red-700">{err}</div>}

        <div className="mt-5 grid md:grid-cols-3 gap-2">
          <input className="rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            placeholder="Titolo" value={form.title} onChange={(e)=>setForm({...form, title:e.target.value})} />
          <input className="rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            placeholder="Tag (comma)" value={form.tags} onChange={(e)=>setForm({...form, tags:e.target.value})} />
          <button className="rounded-xl bg-zinc-900 text-white px-4 py-2 text-sm"
            onClick={async ()=>{
              setErr(null);
              try {
                await apiFetch("/kb", { method:"POST", body: JSON.stringify({ ...form, source:"manual" }) });
                setForm({ title:"", body:"", tags:"" });
                load();
              } catch {
                setErr("Creazione fallita (permessi?).");
              }
            }}
          >
            Crea doc
          </button>
        </div>
        <textarea className="mt-2 w-full rounded-xl border border-zinc-200 px-3 py-2 text-sm min-h-[120px]"
          placeholder="Body" value={form.body} onChange={(e)=>setForm({...form, body:e.target.value})} />

        <div className="mt-6 flex gap-2">
          <input className="rounded-xl border border-zinc-200 px-3 py-2 text-sm flex-1"
            placeholder="Query retrieval (es. disdetta)" value={q} onChange={(e)=>setQ(e.target.value)} />
          <button className="rounded-xl border border-zinc-200 px-4 py-2 text-sm"
            onClick={async ()=>{
              const r = await apiFetch(`/kb/retrieve?query=${encodeURIComponent(q)}`);
              setResults(r.results || []);
            }}
          >
            Cerca
          </button>
        </div>

        {results.length > 0 && (
          <div className="mt-4 space-y-2">
            {results.map((r:any)=> (
              <div key={r.id} className="rounded-xl border border-zinc-200 p-3">
                <div className="text-sm font-medium">{r.title}</div>
                <div className="text-xs text-zinc-500">score: {r.score}</div>
                <div className="mt-1 text-sm text-zinc-700">{r.snippet}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white overflow-hidden">
        <div className="px-4 py-3 text-xs text-zinc-500 border-b border-zinc-200">Documenti</div>
        {docs.map((d:any)=> (
          <div key={d.id} className="px-4 py-4 border-b border-zinc-100">
            <div className="font-medium">{d.title}</div>
            <div className="text-xs text-zinc-500">{d.tags}</div>
            <div className="mt-1 text-sm text-zinc-700 whitespace-pre-wrap">{d.body.slice(0,300)}{d.body.length>300?"…":""}</div>
          </div>
        ))}
        {docs.length === 0 && <div className="p-6 text-sm text-zinc-600">Nessun documento.</div>}
      </div>
    </div>
  );
}
