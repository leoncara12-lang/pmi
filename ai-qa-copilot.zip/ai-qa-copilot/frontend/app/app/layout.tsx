"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { logout } from "../lib/auth";

const NavItem = ({ href, label }: { href: string; label: string }) => {
  const p = usePathname();
  const active = p?.startsWith(href);
  return (
    <Link
      href={href}
      className={
        "rounded-xl px-3 py-2 text-sm " +
        (active ? "bg-zinc-900 text-white" : "text-zinc-700 hover:bg-zinc-100")
      }
    >
      {label}
    </Link>
  );
};

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  return (
    <div className="min-h-screen bg-zinc-50">
      <header className="border-b border-zinc-200 bg-white">
        <div className="mx-auto max-w-6xl px-6 py-4 flex items-center justify-between">
          <div className="font-semibold">AI QA & Compliance Copilot</div>
          <button
            className="text-sm underline"
            onClick={() => {
              logout();
              router.push("/");
            }}
          >
            Logout
          </button>
        </div>
      </header>
      <div className="mx-auto max-w-6xl px-6 py-6 grid md:grid-cols-[220px_1fr] gap-6">
        <aside className="rounded-2xl border border-zinc-200 bg-white p-3 h-fit">
          <div className="text-xs text-zinc-500 px-2 py-1">NAV</div>
          <div className="flex flex-col gap-1">
            <NavItem href="/app/overview" label="Overview" />
            <NavItem href="/app/conversations" label="Conversations" />
            <NavItem href="/app/policies" label="Policies" />
            <NavItem href="/app/kb" label="Knowledge Base" />
          </div>
        </aside>
        <main>{children}</main>
      </div>
    </div>
  );
}
