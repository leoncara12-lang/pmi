"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { apiFetch } from "../../lib/api";

export default function Overview() {
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    apiFetch("/dashboard/overview")
      .then(setData)
      .catch(() => setErr("Non autenticato o backend non raggiungibile."));
  }, []);

  if (err) return <div className="rounded-2xl border border-red-200 bg-white p-6 text-red-700">{err}</div>;
  if (!data) return <div className="text-sm text-zinc-600">Caricamento...</div>;

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-zinc-200 bg-white p-6">
        <div className="text-xl font-semibold">Overview</div>
        <div className="mt-4 grid md:grid-cols-3 gap-4">
          <Card label="Conversations" value={data.total_conversations} />
          <Card label="QA Results" value={data.total_qa_results} />
          <Card label="Latest" value={data.latest?.length || 0} />
        </div>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white p-6">
        <div className="font-semibold">Ultime conversazioni</div>
        <div className="mt-3 space-y-2">
          {data.latest?.map((c:any) => (
            <Link key={c.id} className="block rounded-xl border border-zinc-200 p-3 hover:bg-zinc-50"
              href={`/app/conversations/${c.id}`}>
              <div className="text-sm font-medium">{c.external_id || `Conversation #${c.id}`}</div>
              <div className="text-xs text-zinc-600">{c.queue} • {c.channel}</div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function Card({label, value}:{label:string; value:any}) {
  return (
    <div className="rounded-2xl border border-zinc-200 p-4">
      <div className="text-xs text-zinc-500">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
    </div>
  );
}
