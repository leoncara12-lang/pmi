"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "../../lib/api";

export default function Policies() {
  const [rules, setRules] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", rule_type: "forbidden", pattern: "", severity: "medium", locale: "it-IT", active: true });
  const [err, setErr] = useState<string | null>(null);

  const load = () => apiFetch("/policies").then(setRules).catch(()=>setErr("Errore caricamento (permessi?)"));

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-zinc-200 bg-white p-6">
        <div className="text-xl font-semibold">Policies</div>
        <div className="text-sm text-zinc-600 mt-1">Regole di compliance (MVP). Creazione richiede ruolo admin/qa_lead.</div>
        {err && <div className="mt-3 text-sm text-red-700">{err}</div>}

        <div className="mt-5 grid md:grid-cols-6 gap-2">
          <input className="rounded-xl border border-zinc-200 px-3 py-2 text-sm md:col-span-2"
            placeholder="Nome" value={form.name} onChange={(e)=>setForm({...form, name:e.target.value})} />
          <select className="rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            value={form.rule_type} onChange={(e)=>setForm({...form, rule_type:e.target.value})}>
            <option value="forbidden">forbidden</option>
            <option value="must_include">must_include</option>
            <option value="regex">regex</option>
          </select>
          <select className="rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            value={form.severity} onChange={(e)=>setForm({...form, severity:e.target.value})}>
            <option value="low">low</option>
            <option value="medium">medium</option>
            <option value="high">high</option>
          </select>
          <input className="rounded-xl border border-zinc-200 px-3 py-2 text-sm md:col-span-2"
            placeholder="Pattern (regex o stringa)" value={form.pattern} onChange={(e)=>setForm({...form, pattern:e.target.value})} />
        </div>

        <button className="mt-3 rounded-xl bg-zinc-900 text-white px-4 py-2 text-sm"
          onClick={async ()=>{
            setErr(null);
            try {
              await apiFetch("/policies", { method: "POST", body: JSON.stringify(form) });
              setForm({ name: "", rule_type: "forbidden", pattern: "", severity: "medium", locale: "it-IT", active: true });
              load();
            } catch (e:any) {
              setErr("Creazione fallita: permessi o pattern non valido.");
            }
          }}
        >
          Crea regola
        </button>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white overflow-hidden">
        <div className="px-4 py-3 text-xs text-zinc-500 border-b border-zinc-200">Regole</div>
        {rules.map((r:any)=> (
          <div key={r.id} className="px-4 py-4 border-b border-zinc-100">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">{r.name}</div>
                <div className="text-xs text-zinc-500">{r.rule_type} • {r.severity} • {r.locale} • active={String(r.active)}</div>
                <div className="mt-1 text-sm text-zinc-700 font-mono break-all">{r.pattern}</div>
              </div>
              <button className="text-sm underline"
                onClick={async ()=>{
                  try {
                    await apiFetch(`/policies/${r.id}`, { method: "DELETE" });
                    load();
                  } catch {
                    setErr("Delete fallita (permessi?).");
                  }
                }}
              >
                Delete
              </button>
            </div>
          </div>
        ))}
        {rules.length === 0 && <div className="p-6 text-sm text-zinc-600">Nessuna regola.</div>}
      </div>
    </div>
  );
}
