import { apiFetch, setToken, clearToken } from "./api";

export async function login(email: string, password: string) {
  const r = await apiFetch("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
  setToken(r.access_token);
  return r;
}

export async function register(tenant_name: string, email: string, password: string, full_name: string) {
  return apiFetch("/auth/register", { method: "POST", body: JSON.stringify({ tenant_name, email, password, full_name, role: "admin" }) });
}

export async function me() {
  return apiFetch("/auth/me");
}

export function logout() {
  clearToken();
}
