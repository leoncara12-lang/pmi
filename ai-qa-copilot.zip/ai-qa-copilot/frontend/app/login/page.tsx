"use client";

import { useState } from "react";
import Link from "next/link";
import { login } from "../lib/auth";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const router = useRouter();

  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md rounded-2xl border border-zinc-200 p-6">
        <h1 className="text-xl font-semibold">Login</h1>
        <p className="text-sm text-zinc-600 mt-1">Accedi al dashboard.</p>

        <div className="mt-5 space-y-3">
          <input className="w-full rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
          <input className="w-full rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            placeholder="Password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
          {err && <div className="text-sm text-red-600">{err}</div>}
          <button
            onClick={async () => {
              setErr(null);
              try {
                await login(email, password);
                router.push("/app/overview");
              } catch (e:any) {
                setErr("Credenziali non valide o server non raggiungibile.");
              }
            }}
            className="w-full rounded-xl bg-zinc-900 text-white px-4 py-2 text-sm"
          >
            Entra
          </button>
        </div>

        <div className="mt-4 text-sm text-zinc-600">
          Non hai un account? <Link className="underline" href="/register">Registrati</Link>
        </div>
        <div className="mt-2 text-xs text-zinc-500">
          Token salvato in localStorage (MVP). In produzione usa cookie httpOnly + refresh token.
        </div>
      </div>
    </main>
  );
}
