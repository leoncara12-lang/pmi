import Link from "next/link";

export default function Landing() {
  return (
    <main className="min-h-screen">
      <header className="mx-auto max-w-6xl px-6 py-6 flex items-center justify-between">
        <div className="font-semibold">AI QA & Compliance Copilot</div>
        <nav className="flex gap-3">
          <Link className="text-sm underline" href="/login">Login</Link>
          <Link className="text-sm underline" href="/register">Registrati</Link>
        </nav>
      </header>

      <section className="mx-auto max-w-6xl px-6 py-16 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold leading-tight">
            QA e Compliance su <span className="underline">100%</span> delle conversazioni.
          </h1>
          <p className="mt-5 text-lg text-zinc-600">
            Importa chat/email, redigi PII, applica regole di compliance e ottieni score QA con evidenze.
            Poi fai upsell ad Agent Assist.
          </p>
          <div className="mt-8 flex gap-3">
            <Link href="/register" className="rounded-xl bg-zinc-900 text-white px-5 py-3 text-sm">
              Inizia il pilot
            </Link>
            <Link href="/login" className="rounded-xl border border-zinc-200 px-5 py-3 text-sm">
              Accedi
            </Link>
          </div>
          <div className="mt-8 text-xs text-zinc-500">
            MVP completo: landing + login + dashboard + backend + Postgres + worker Celery.
          </div>
        </div>

        <div className="rounded-2xl border border-zinc-200 p-6 shadow-sm">
          <div className="text-sm font-semibold">Cosa ottieni</div>
          <ul className="mt-4 space-y-3 text-sm text-zinc-700">
            <li>✅ Score QA (accuracy, tone, process, resolution)</li>
            <li>✅ Compliance findings (must include / forbidden / regex)</li>
            <li>✅ PII redaction (email, IBAN, CF, phone, cc)</li>
            <li>✅ Dashboard trend + drill-down</li>
            <li>✅ KB + retrieval stub per Agent Assist</li>
          </ul>
          <div className="mt-6 rounded-xl bg-zinc-50 p-4 text-sm">
            <div className="font-semibold">Suggerimento</div>
            <p className="mt-2 text-zinc-600">
              Parti con chat/email. Aggiungi voice dopo, quando hai ROI e governance pronta.
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-10">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {t:"Setup veloce", d:"Import CSV/JSON o integra il ticketing. Inizia in giorni, non mesi."},
            {t:"Guardrail UE-ready", d:"Audit log, RBAC, retention, redaction, regole versionabili."},
            {t:"Land & expand", d:"Dalla QA alla sidebar Agent Assist. Misuri e poi espandi."},
          ].map((c, i) => (
            <div key={i} className="rounded-2xl border border-zinc-200 p-6">
              <div className="font-semibold">{c.t}</div>
              <div className="mt-2 text-sm text-zinc-600">{c.d}</div>
            </div>
          ))}
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-6 py-10 text-xs text-zinc-500">
        © {new Date().getFullYear()} AI QA & Compliance Copilot — MVP
      </footer>
    </main>
  );
}
