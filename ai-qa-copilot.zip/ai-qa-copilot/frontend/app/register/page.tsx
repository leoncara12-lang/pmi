"use client";

import { useState } from "react";
import Link from "next/link";
import { register } from "../lib/auth";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const [tenant, setTenant] = useState("default");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const router = useRouter();

  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md rounded-2xl border border-zinc-200 p-6">
        <h1 className="text-xl font-semibold">Registrazione</h1>
        <p className="text-sm text-zinc-600 mt-1">Crea tenant e utente admin.</p>

        <div className="mt-5 space-y-3">
          <input className="w-full rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            placeholder="Tenant (es. miaazienda)" value={tenant} onChange={(e)=>setTenant(e.target.value)} />
          <input className="w-full rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            placeholder="Nome e Cognome" value={fullName} onChange={(e)=>setFullName(e.target.value)} />
          <input className="w-full rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
          <input className="w-full rounded-xl border border-zinc-200 px-3 py-2 text-sm"
            placeholder="Password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
          {err && <div className="text-sm text-red-600">{err}</div>}
          <button
            onClick={async () => {
              setErr(null);
              try {
                await register(tenant, email, password, fullName);
                router.push("/login");
              } catch (e:any) {
                setErr("Registrazione fallita (email già usata?).");
              }
            }}
            className="w-full rounded-xl bg-zinc-900 text-white px-4 py-2 text-sm"
          >
            Crea account
          </button>
        </div>

        <div className="mt-4 text-sm text-zinc-600">
          Hai già un account? <Link className="underline" href="/login">Login</Link>
        </div>
      </div>
    </main>
  );
}
